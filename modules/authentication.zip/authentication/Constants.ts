export const AuthConstants = {
  // url: 'http://localhost:7000',
  url: 'https://pixelplux.com/authentication',
};
