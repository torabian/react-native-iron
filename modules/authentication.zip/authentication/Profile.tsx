import React from 'react';

import {View, StyleSheet, Text} from 'react-native';

export const Profile = ({}: {}) => {
  return (
    <View style={styles.wrapper}>
      <Text>Hi@@@@</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {flex: 1},
});
